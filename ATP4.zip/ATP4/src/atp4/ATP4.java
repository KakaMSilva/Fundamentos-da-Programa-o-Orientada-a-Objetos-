package atp4;

import java.util.ArrayList;
import java.util.Scanner;


public class ATP4 {
    
    
    public static ArrayList<Funcionario> Funcionario;
    
  
    public static void main(String[] args) {
        
    Scanner teclado = new Scanner(System.in);    
    int quantidade, dependentes;
     
     
        do{
        System.out.println("Digite um numero de 1 ao 100");
        quantidade = teclado.nextInt();     
    
        
     Funcionario = new ArrayList<Funcionario>();
           
        int c = 0;                                
        while(c < quantidade){
        
        
            System.out.println("Codigo"); 
            int codigo = teclado.nextInt();  
            
            System.out.println("Salário base:"); 
            double salario = teclado.nextDouble();
            
            System.out.println("Tempo de contratação");
            int tempo = teclado.nextInt();
            
            System.out.println("o tipo 1 para funcionário Efetivado ou o tipo 2 para funcionário Estagiario");
            int tipo = teclado.nextInt();
           

            //Ira se repetir ate que esteja entre 0 e 5
            do{
            System.out.println("Possui dependente? se sim quantos? ");  
            dependentes = teclado.nextInt();
            } while (dependentes >= 0 != dependentes <= 5); 
            
            ArrayList<Dependente> Dependentis = new ArrayList<Dependente>();
            
            int b = 0;    
            
            while (b < dependentes ){
                System.out.println("------Dependente:" +b+ "------");  

                System.out.println("Qual sua idade?");
                int idade = teclado.nextInt();
                
                Dependente d = new Dependente(idade); 
                Dependentis.add(d);
           
                System.out.println("--------------------------------");
                
            b++;   
            }
     
            if (tipo == 1 ){
                
              FuncionarioConcursado Concursado = new FuncionarioConcursado(codigo, salario, tempo); 
              
              
            for(Dependente d :Dependentis){
              Concursado.associadepentende(d);
              }
            
            Funcionario.add(Concursado);
              
            }else{
              FuncionarioTemporario Temporario = new FuncionarioTemporario(codigo, salario, tempo);  
             
              
            for(Dependente d :Dependentis){
              Temporario.associadepentende(d);
              }
              
            Funcionario.add(Temporario); 
            
            }      
     c++;
     }  
        for (Funcionario Funcionario : Funcionario){
            Funcionario.imprime();
        }
        

        
        
     } while (quantidade >= 1 != quantidade <= 100);   
    }
    
}