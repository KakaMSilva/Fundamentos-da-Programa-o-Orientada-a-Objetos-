package atp4;
import java.util.ArrayList;

public class Funcionario {
 
  protected int codigo;   
  protected double salario;   
  protected int tempo;    
  protected double valormensal;  
  
 public  ArrayList<Dependente> Dependentis = new ArrayList<Dependente>();
  
    public  boolean associadepentende (Dependente d) {
       Dependentis.add(d);
       return true;
}     
    
    public int idadelimiteb (int idade){
     int totalidade = 0;
      for (Dependente d : this.Dependentis){
       if (d.idadelimitea(idade)){
         totalidade++;
       }          
      }
      return totalidade;
} 
    
    
    
    
    

   public void imprime(){  
 System.out.println("--------------------------------------------------------------");
 System.out.println("Funcionário com código "+ codigo+ ", Concursado, com salário-base de "+ salario+ " , "+ tempo+ " anos de contratação");       
 System.out.println("--------------------------------------------------------------");
}
}
