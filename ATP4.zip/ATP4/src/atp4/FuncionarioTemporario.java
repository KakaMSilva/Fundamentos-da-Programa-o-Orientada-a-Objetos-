package atp4;
public class FuncionarioTemporario extends Funcionario{
   
public FuncionarioTemporario(int codigo, double salario, int tempo) {
        this.codigo = codigo;
        this.salario = salario;
        this.tempo = tempo;
    }    
    
   public double calcularvalormensal(){   
   return valormensal = (this.calculaSalario() * 50) + salario + (15 * tempo);  
   } 

   public double  calculaSalario() {
   
    return  this.idadelimiteb(18);
   
   }

   
 @Override
 public void imprime(){
 
 super.imprime(); 
    
 int sDependentes = 0;
  for(int i = 0; i < this.Dependentis.size(); i++){
      if(this.Dependentis.get(i).idadelimitea(18) == true){
         sDependentes++;
  }
  }   
     System.out.println("--------------------------------------------------------------");
     System.out.println("Dependentes dentro da idade limite: "+  this.idadelimiteb(18));
     System.out.println("salario total: " +calcularvalormensal());  
     System.out.println("--------------------------------------------------------------");

}  
}

