package atp4;
public class Dependente extends Funcionario{
    
 protected int idade;
 
    public Dependente(int idade) {
        this.idade = idade;
    }    
    
 public boolean idadelimitea(int idade) {
  
    if(this.idade <= idade){
    return true;
    }else{
    return false;    
    }
 }
}


 