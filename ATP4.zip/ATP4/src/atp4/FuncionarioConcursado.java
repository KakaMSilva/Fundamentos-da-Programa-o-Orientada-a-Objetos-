package atp4;
public class FuncionarioConcursado extends Funcionario{
    
      protected FuncionarioConcursado(int codigo, double salario, int tempo) {
        this.codigo = codigo;
        this.salario = salario;
        this.tempo = tempo;
    }   
    
   public double calcularvalormensal(){   
   return valormensal = (this.calculaSalario() * 100) + salario + (200 * tempo);  
   } 
   
   public double  calculaSalario() {
   
    return  this.idadelimiteb(21);
   
   }
   
   
 @Override
 public void imprime(){
     
     
super.imprime();
 
 int sDependentes = 0;
  for(int i = 0; i < this.Dependentis.size(); i++){
      if(this.Dependentis.get(i).idadelimitea(21) == true){
         sDependentes++;
  } 
  }
     System.out.println("--------------------------------------------------------------");
     System.out.println("Dependentes dentro da idade limite: "+  this.idadelimiteb(21));
     System.out.println("salario total: " +calcularvalormensal());  
     System.out.println("--------------------------------------------------------------");

}
}

