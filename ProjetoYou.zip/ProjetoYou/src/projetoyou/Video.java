package projetoyou;
public class Video implements Açoes{
    private String titulo;
    private int avaliaçoes;
    private int views;
    private int curtidas;
    private boolean reproduzindo;

    public Video(String titulo) {
        this.titulo = titulo;
        this.avaliaçoes = 1;
        this.views = 0;
        this.curtidas = 0;
        this.reproduzindo = false;
    }

    
    
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getAvaliaçoes() {
        return avaliaçoes;
    }

    public void setAvaliaçoes(int avaliaçoes) {
        int nova;
        nova = (int) ((this.avaliaçoes + avaliaçoes)/this.views);
        this.avaliaçoes = nova;
    }

    public int getViews() {
        return views;
    }

    public void setViews(int views) {
        this.views = views;
    }

    public int getCurtidas() {
        return curtidas;
    }

    public void setCurtidas(int curtidas) {
        this.curtidas = curtidas;
    }

    public boolean isReproduzindo() {
        return reproduzindo;
    }

    public void setReproduzindo(boolean reproduzindo) {
        this.reproduzindo = reproduzindo;
    }
          
    @Override
    public void play() {

    }

    @Override
    public void pause() {

    }

    @Override
    public void like() {

    }

    @Override
    public String toString() {
        return "Video{" + "titulo=" + titulo + ", avalia\u00e7oes=" + avaliaçoes + ", views=" + views + ", curtidas=" + curtidas + ", reproduzindo=" + reproduzindo + '}';
    }
    
}
