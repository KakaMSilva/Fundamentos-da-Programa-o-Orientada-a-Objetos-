package projetoyou;
public interface Açoes {
    public void play();
    public void pause();
    public void like();
}
